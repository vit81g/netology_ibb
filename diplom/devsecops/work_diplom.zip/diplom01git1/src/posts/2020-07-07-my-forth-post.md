---
title: 'My forth post'
description: Lorem ipsum dolor sit amet, consectetur adipiscing elit.
date: 2020-07-07T00:00:00Z
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Example with image:

![Error](/assets/images/posts/error.png)

Example code block:

```js
function myFunction() {
  return true;
}
```
