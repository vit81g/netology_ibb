---
title: 'My second post'
description: Lorem ipsum dolor sit amet, consectetur adipiscing elit.
date: 2020-03-03T00:00:00Z
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit.

Example with image:

![Error](/assets/images/posts/error.png)

Example code block:

```js
function myFunction() {
  return true;
}
```
